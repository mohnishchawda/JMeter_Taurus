import sys

import pandas as pd

pd.set_option('display.max_rows', 10000)
pd.set_option('display.max_columns', 100)
pd.set_option('display.width', 10000)


def analyse(data_frame):
    data_frame = data_frame[~data_frame['label'].str.contains('/')]
    data_frame = data_frame.groupby(['label']).agg(
        {'label': 'size', 'elapsed': ['mean', 'min', 'max', 'std'], 'success': 'sum'})
    data_frame.columns = data_frame.columns.droplevel()
    data_frame['Fail'] = data_frame['size'] - data_frame['sum']
    data_frame['Error_%'] = (1 - data_frame['sum'] / data_frame['size']) * 100
    data_frame = get_throughput(data_frame)
    data_frame = data_frame.rename(
        columns={'size': 'Total', 'mean': 'Average', 'min': 'Min', 'max': 'Max', 'std': 'Std_Dev', 'sum': 'Pass'})
    data_frame = data_frame[['Min', 'Average', 'Max', 'Std_Dev', 'Total', 'Pass', 'Fail', 'Error_%', 'Throughput/Min']]
    data_frame = get_percentile(data_frame, 0.9)
    data_frame = get_percentile(data_frame, 0.95)
    data_frame = get_percentile(data_frame, 0.99)
    print(data_frame)


def get_percentile(data_frame, percentile):
    for index, row in data_frame.iterrows():
        df = DATA_FRAME_RAW[DATA_FRAME_RAW['label'] == index]
        data_frame.at[index, str(int(percentile * 100)) + 'th_Percentile'] = df['elapsed'].quantile(percentile, interpolation='higher')
    return data_frame


def get_throughput(data_frame):
    for index, row in data_frame.iterrows():
        df = DATA_FRAME_RAW[DATA_FRAME_RAW['label'] == index]
        duration = get_test_duration_minutes(df)
        data_frame.at[index, 'Throughput/Min'] = round(row['size'] / duration, 1)
    return data_frame


def get_test_duration_minutes(data_frame):
    start_timestamp = data_frame['timeStamp'].head(1).iat[0]
    end_timestamp = data_frame['timeStamp'].tail(1).iat[0] + data_frame['elapsed'].tail(1).iat[0]
    test_duration = end_timestamp - start_timestamp
    return test_duration / 1000 / 60


DATA_FRAME_RAW = pd.read_csv(sys.argv[1])
# DATA_FRAME_RAW = pd.read_csv('output/jmeter_raw.csv')
analyse(DATA_FRAME_RAW)
